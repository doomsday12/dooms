from enum import Enum


class PetType(Enum):
    CAT = "cat"
    DOG = "dog"
